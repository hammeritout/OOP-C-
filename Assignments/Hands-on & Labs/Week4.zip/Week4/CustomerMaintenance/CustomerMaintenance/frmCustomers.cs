using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerMaintenance
{
    public partial class frmCustomers : Form
    {
        public frmCustomers()
        {
            InitializeComponent();
        }
        // Declaring a Customer class with list type variable

        private List<Customer> customers = null;
      //  public List<Customer> frmCustomers.customers = null;

        //Loads the customers records from the Customer.DB and places the customer records in the List Box.
        private void frmCustomers_Load(object sender, EventArgs e)
        {
            customers = CustomerDB.GetCustomers();
            FillCustomerListBox();
        }
        private void FillCustomerListBox()
        {
            lstCustomers.Items.Clear();
            foreach (Customer c in customers)
            {
                lstCustomers.Items.Add(c.GetDisplayText("\t"));

            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmAddCustomer newCustomerForm = new frmAddCustomer();
            Customer customer = newCustomerForm.GetNewCustomer();
            if (customer != null)
            {
                customers.Add(customer);
                CustomerDB.SaveCustomers(customers);
                FillCustomerListBox();
            }
        }
        // this code is executed when the Delete button is clicked.
        private void btnDelete_Click(object sender, EventArgs e)
        {
            int i = lstCustomers.SelectedIndex;
            if (i != -1)
            {
                Customer customer = customers[i];
                string message = "Are you sure you want to delete "
                    + customer.Email + "?";
                DialogResult button =
                    MessageBox.Show(message, "Confirm Delete",
                    MessageBoxButtons.YesNo);
                if (button == DialogResult.Yes)
                {
                    customers.Remove(customer);
                    CustomerDB.SaveCustomers(customers);
                    FillCustomerListBox();

                }
            }
        }
        // this code closes the form when the exit button is clicked
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
// Customer Class Project
// Student: Sharyl Hammer
// Fall 2016 
// September 18,2016

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerMaintenance
{
    public partial class frmAddCustomer : Form
    {
        public frmAddCustomer()
        {
            InitializeComponent();

        }

        // Declare a variable named customer in the Customer class that has a vaule of null.
        private Customer customer = null;

        //Declared a mehod number GetNewCustomer that will display the form in a DialogBox and return the Customer object
        public Customer GetNewCustomer()
        {
            this.ShowDialog(); 
            return customer;
        }

        private void frmAddCustomer_Load(object sender, EventArgs e)
              {



              }

        // When the save button is clicked this event will run and validate the entered in FirstName, LastName and Email variables.
        // The Validator class is called which will validate the fields.


        private void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                customer = new Customer(txtFirstName.Text,
                txtLastName.Text, txtEmail.Text);
                this.Close();

            } // IsValid Data 
        }

            // Validates the Data and calls methods from the Validator class which are IsPresent and IsValidEmail and passes the Text box  value of the property. 
            private bool IsValidData()
              {
            return Validator.IsPresent(txtFirstName) &&
                   Validator.IsPresent(txtLastName) &&
                   Validator.IsPresent(txtEmail) &&
                   Validator.IsValidEmail(txtEmail);
             }
       
         
          // Closes the form when the cancel button is clicked.
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }   // Cancel
    
   }

}
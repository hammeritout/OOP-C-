﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerMaintenance
{
    public class RetailCustomer : Customer
    {
        //created the private string homephone field

        private string homephone;

        //created an Empty Constructor 
        public RetailCustomer()
            {
            
            }
        public RetailCustomer(string firstname, string lastname, string email, string homephone)
               :base(firstname,lastname,email)
        {
            this.HomePhone = homephone;
        }
      
        public string HomePhone
        {
            get
            {
                return homephone;
            }
            set
            {
                homephone = value;

              //  StringBuilder homephone = new StringBuilder(10);
               // homephone.Insert(1, "(");
               // homephone.Insert(3, ")");
               // homephone.Insert(6, "-");
                
            }
        }
          
                 
        //need to format homephone 
        public override string GetDisplayText()  => base.GetDisplayText() + "ph. " + homephone;
          
            
          

    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 Sharyl Hammer
 ITD 2263 GUI
 October 16, 2016
 */

namespace CustomerMaintenance
{
     public class WholesaleCustomer : Customer
    {   
        // created string company

        private string company;

        // created and Empty Constructor
        public WholesaleCustomer()
        {

        }
        // created a Constructor that uses the base of the Customer properties.
        // firstname, lastname, email

        public WholesaleCustomer(string firstname,string lastname, string email, string company) :base(firstname,lastname,email)
        {
            this.Company = company;
        }

        // created Property company which gets the value company. 
        // firstname, lastname and email are accessed through the base class Customer 

        public string Company
        {
         get
            {
                return company;
            }
            set
            {
                company = value;
            }

        }


        public override string GetDisplayText() =>  base.GetDisplayText() + "(" + company +")";

        



    }
}

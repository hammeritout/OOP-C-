using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerMaintenance
{
    public class Customer
	{
		private string firstName;
		private string lastName;
		private string email;

		public Customer()
		{
		}

		public Customer(string firstName, string lastName, string email)
		{
			this.FirstName = firstName;
			this.LastName = lastName;
			this.Email = email;
		}

        // An indexer the validates data and throws an argument exception

                
        public string FirstName
		{
			get
			{
                if (firstName.Length > 30)
                {
                    // Throws an exception if first name is over 30 characters.
                    throw new ArgumentException("Maximum length of first name is 30 characters");
                }

             return firstName;
			}
			set
			{
				firstName = value;
			}
		}

		public string LastName
		{
			get
			{
                if (lastName.Length > 30)
                {
                    // Throws an exception if last name is over 30 characters.
                    throw new ArgumentException("Maximum length of last name is 30 characters");
                }

                return lastName;
			}
			set
			{
				lastName = value;
			}
		}

		public string Email
		{
			get
			{

                if (email.Length > 30)
                {
                    // Throws an exception if email is over 30 characters.
                    throw new ArgumentException("Maximum length of email is 30 characters");
                }

                return email;
			}
			set
			{
				email = value;
			}
		}

		public string GetDisplayText() => firstName + " " + lastName + ", " + email;
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* Sharyl Hammer
   ITD Graphical User Interface 2263 
   Fall 2016
   J. Strother
   October 9, 2016
*/
namespace CustomerMaintenance
{
    // Created CustomerList class

    public class CustomerList
    {
        public delegate void ChangeHandler(CustomerList customers);
        public event ChangeHandler Changed;

        //private variable to declare a list of Customr objects.

        private List<Customer> customers;

       
       
        // Constructor which is the same name as the class object.

        public CustomerList()
        {
            customers = new List<Customer>();
        }

    // Using an indexer provides access to the customer at a specified position. 
    //get accessor uses an integer index to return a Customer object from the customer list based on it position in the list.

    public Customer this[int i]
        {
          get { return customers[i]; }
          set {
                customers[i] = value;
                Changed(this);
              }
          
        }


        //Property Count created with an expression-bodied property using the lambda 
          public int Count => customers.Count;


        // Add Customer method
        // Add overload operator using the + operator to add records to the customer list 
        
        //  public void Add(Customer customer)
        //   {
        //   customers.Add(customer);
        //  Changed(this);
        //  }

          public void Add(Customer c)
             {
           customers.Add(c);
           Changed(this);
             }


        // Added overloaded operator + to add object customer to the list
        // When using overloaded operator access needs to be static need keyword operator with the +

        public static CustomerList operator +(CustomerList c1, Customer c)
        {
            c1.Add(c);
            return c1;
        }
        
        // Add Customer method 
        // Overloaded method used the same method name but different parameters

        //      public void Add(string firstName, string lastName, string email)
        //    {
        //    Customer c = new Customer(firstName, lastName, email);
        // customers.Add(c);

        //   Changed(this);

        // }

        public static CustomerList operator -(CustomerList c1, Customer c)
        {
            c1.Remove(c);
            return c1;
        }
    
         public void Remove(Customer c)
        {
          customers.Remove(c);
           Changed(this);
       }
        // added the Fill() method using expression bodied property with the lambda 
        public void Fill() => customers = CustomerDB.GetCustomers();

        // added the Save() methos using the expression bodied property with the lambda

        public void Save() => CustomerDB.SaveCustomers(customers);

    }
}

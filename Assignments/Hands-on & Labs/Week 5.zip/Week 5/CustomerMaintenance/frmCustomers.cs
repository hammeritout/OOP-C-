using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerMaintenance
{
    public partial class frmCustomers : Form
    {
        public frmCustomers()
        {
            InitializeComponent();
        }
        // Commented out to use the CustomerList Class 
  //old  //    private List<Customer> customers = null;

         private CustomerList customers = new CustomerList();  //new code using the CustomerList class

        
       
            private void frmCustomers_Load(object sender, EventArgs e)
        {
            customers.Changed += new CustomerList.ChangeHandler(HandleChange);

            // old customers = CustomerDB.GetCustomers();

            // new code calls the method Fill() from the  CustomerList object.    

            customers.Fill();
            FillCustomerListBox();
        }

        private void FillCustomerListBox()
        {
            Customer c;  // new code
            lstCustomers.Items.Clear();
            //old    foreach (Customer c in customers)
            for (int i=0; i< customers.Count; i++)   //new code using for loop with Count property
            {
                c = customers[i];  //  using an indexer for the customers object. 
                lstCustomers.Items.Add(c.GetDisplayText());
            }
        }

      //
         private void btnAdd_Click(object sender, EventArgs e)
        {
          

            frmAddCustomer addCustomerForm = new frmAddCustomer();
            Customer customer = addCustomerForm.GetNewCustomer();
            if (customer != null)
            {

                //old  customers.Add(customer);
                customers += customer;  //uses the event handler

                //old//   CustomerDB.SaveCustomers(customers);
               // new code get the save method from the CustomerList class.
                customers.Save();
                FillCustomerListBox();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int i = lstCustomers.SelectedIndex;
            if (i != -1)
            {
                Customer customer = (Customer)customers[i];
                string message = "Are you sure you want to delete "
                    + customer.FirstName + " " + customer.LastName + "?";
                DialogResult button = MessageBox.Show(message, "Confirm Delete",
                    MessageBoxButtons.YesNo);
                if (button == DialogResult.Yes)
                {
                    // customers.Remove(customer);
                    
                    customers -= customer; //uses the changed event 
                    customers.Save(); // new code reference the customers object  
                 //   CustomerDB.SaveCustomers(customers); 
                    FillCustomerListBox();
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void HandleChange(CustomerList customers) //added this method for the event
        {
            customers.Save();
            FillCustomerListBox();

        }
    }
}
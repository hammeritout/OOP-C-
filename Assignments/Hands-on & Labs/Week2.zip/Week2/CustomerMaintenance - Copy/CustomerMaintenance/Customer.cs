﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerMaintenance
{
    class Customer
    {
        // Private Fields Accessed by the Customer Class
        private string firstname;
        private string lastname;
        private string email;

        // Empty constructor
        public Customer()
        {
        }

        // Constructor that assigns values  
        public Customer(string firstname, string lastname, string email)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.Email = email;
        }

        // Read/write Properties (FirstName, LastName, Email)   using the get and set accessors 

        public string FirstName
        {
            get {return firstname;}
            set {firstname = value;}  
        }

         public string LastName
        {
            get {return lastname;}
            set { lastname = value;} 
            
        }

        public string Email
          {
            get { return email; }
            set { email = value; }
          }

        // Create the Get Display Text Method

             public string GetDisplayText()
             {
            return firstname + " " + lastname + " " + email;

             }



    }
}



